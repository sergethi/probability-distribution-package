from setuptools import setup

setup(name='srg_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['srg_distributions'],
      author = 'sergethiPytest',
      author_email = 'nsergearistide@gmail.com',
      zip_safe=False)
